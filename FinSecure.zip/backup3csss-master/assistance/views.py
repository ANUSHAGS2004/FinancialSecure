from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.core.mail import send_mail
from .forms import FinancialProfileForm
from .models import FinancialProfile, AssistanceResult
from users.models import UserProfile
from .ml_model import predict_assistance, train_model
from users.utils import fetch_recent_transactions, generate_suggestions

import os
import google_auth_oauthlib.flow
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

@login_required
def connect_gmail(request):
    flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
        os.path.join(settings.BASE_DIR, 'credentials.json'),
        scopes=SCOPES
    )
    flow.redirect_uri = "http://127.0.0.1:8080/assistance/oauth2callback"
    authorization_url, state = flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true"
    )
    request.session['state'] = state
    return redirect(authorization_url)

@login_required
def oauth2callback(request):
    state = request.session['state']
    flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
        os.path.join(settings.BASE_DIR, 'credentials.json'),
        scopes=SCOPES,
        state=state
    )
    flow.redirect_uri = "http://127.0.0.1:8080/assistance/oauth2callback"
    flow.fetch_token(authorization_response=request.build_absolute_uri())
    credentials = flow.credentials
    with open("token.json", "w") as token:
        token.write(credentials.to_json())
    return redirect('dashboard')

def get_latest_emails():
    creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    service = build('gmail', 'v1', credentials=creds)
    results = service.users().messages().list(userId='me', maxResults=5).execute()
    messages = results.get('messages', [])
    emails = []
    for msg in messages:
        msg_data = service.users().messages().get(userId='me', id=msg['id']).execute()
        headers = msg_data['payload']['headers']
        subject = next((h['value'] for h in headers if h['name'] == 'Subject'), '(No Subject)')
        sender = next((h['value'] for h in headers if h['name'] == 'From'), '(Unknown Sender)')
        snippet = msg_data.get('snippet', '')
        emails.append({'subject': subject, 'from': sender, 'snippet': snippet})
    return emails

@login_required
def dashboard(request):
    user = request.user
    gmail_connected = os.path.exists("token.json")

    # Fetch user profile data as usual
    user_profile = None
    profile_data = {}
    try:
        user_profile = UserProfile.objects.get(user=user)
        profile_data = {
            'income': getattr(user_profile, 'income', 0),
            'expenses': getattr(user_profile, 'expenses', 0),
            'monthly_savings_goal': getattr(user_profile, 'monthly_savings_goal', 0),
            'debts': getattr(user_profile, 'debts', 0),
            'monthly_investment': getattr(user_profile, 'monthly_investment', 0),
            'risk_tolerance': getattr(user_profile, 'risk_tolerance', 'Medium'),
        }
    except UserProfile.DoesNotExist:
        pass

    # Your existing code to fetch transactions, emails...

    # --- Retrieve latest profile and undo saved suggestions ---
    saved_profile = None
    suggestions = []
    if user_profile:
        saved_profile = FinancialProfile.objects.filter(user=user).last()
        if saved_profile and saved_profile.suggestion:
            suggestions = saved_profile.suggestion.split('\n')

    # Pass 'suggestions' to template
    return render(request, "users/dashboard.html", {
        "profile": profile_data,
        "suggestions": suggestions,  # user-specific suggestions here
        "gmail_connected": gmail_connected,
        # Other context variables such as emails, transactions, etc.
    })



@login_required
def assist_home(request):
    if request.method == 'POST':
        form = FinancialProfileForm(request.POST)
        if form.is_valid():
            profile = form.save(commit=False)

            # Assign the current logged-in user to the profile
            profile.user = request.user

            # Financial heuristics and suggestion messages
            suggestion_messages = []
            net_savings = profile.income - profile.expenses

            if net_savings > 10000:
                suggestion_messages.append("💡 Your savings are healthy. You can invest more.")
            else:
                suggestion_messages.append("⚠️ Consider reducing expenses to improve savings.")

            if profile.credit_score >= 750:
                suggestion_messages.append("✅ Excellent credit score. Eligible for premium loans or credit cards.")
            elif 650 <= profile.credit_score < 750:
                suggestion_messages.append("⚠️ Average credit score. Improve your credit for better options.")
            else:
                suggestion_messages.append("⚠️ Low credit score. Work on repayments to improve your score.")

            if getattr(profile, 'debts', 0) > 0:
                suggestion_messages.append(f"⚠️ You have outstanding debts of ₹{profile.debts}. Try reducing them.")
            else:
                suggestion_messages.append("✅ No debts. Keep up good financial health.")

            if getattr(profile, 'monthly_investment', 0) > 0:
                suggestion_messages.append("💡 Your current investments are on track.")
            else:
                suggestion_messages.append("💡 Consider starting small investments based on your risk tolerance.")

            risk = getattr(profile, 'risk_tolerance', 'Medium')
            if risk.lower() == "high":
                suggestion_messages.append("⚠️ High risk tolerance. Diversify your investments.")
            elif risk.lower() == "low":
                suggestion_messages.append("✅ Low risk tolerance. Prefer safer investments.")

            if getattr(profile, 'monthly_savings_goal', 0) > net_savings:
                suggestion_messages.append("⚠️ Your savings goal is higher than your current net savings. Please adjust your budget.")

            if getattr(profile, 'financial_goals', ''):
                suggestion_messages.append(f"💡 Your financial goal: {profile.financial_goals}")

            # Gmail transaction-based suggestions
            gmail_suggestions = []
            try:
                transactions = fetch_recent_transactions(request.user.email)
                if transactions:
                    gmail_suggestions = generate_suggestions(profile.__dict__, transactions)
            except Exception as e:
                print("Error fetching Gmail transactions:", e)
                gmail_suggestions.append("⚠️ Could not fetch Gmail transactions. Check Gmail API setup.")

            # Combine all suggestions and save to profile
            profile.suggestion = "\n".join(suggestion_messages + gmail_suggestions)

            # Train ML model (ideally done asynchronously or less frequently)
            train_model(FinancialProfile.objects.all())

            # Predict assistance requirement
            assistance_required = predict_assistance(profile)
            if assistance_required is None:
                assistance_required = net_savings <= 10000 or profile.credit_score < 700

            # Save the profile with user and suggestions
            profile.save()

            # Save AssistanceResult linked to user profile
from django.utils import timezone

@login_required
def assist_home(request):
    if request.method == 'POST':
        form = FinancialProfileForm(request.POST)
        if form.is_valid():
            # Update or create unique profile for current user
            try:
                profile = FinancialProfile.objects.get(user=request.user)
                for field, value in form.cleaned_data.items():
                    setattr(profile, field, value)
            except FinancialProfile.DoesNotExist:
                profile = form.save(commit=False)
                profile.user = request.user

            # Heuristic suggestion messages
            suggestion_messages = []
            net_savings = profile.income - profile.expenses
            if net_savings > 10000:
                suggestion_messages.append("💡 Your savings are healthy. You can invest more.")
            else:
                suggestion_messages.append("⚠️ Consider reducing expenses to improve savings.")

            if profile.credit_score >= 750:
                suggestion_messages.append("✅ Excellent credit score. Eligible for premium loans or credit cards.")
            elif 650 <= profile.credit_score < 750:
                suggestion_messages.append("⚠️ Average credit score. Improve your credit for better options.")
            else:
                suggestion_messages.append("⚠️ Low credit score. Work on repayments to improve your score.")

            if getattr(profile, 'debts', 0) > 0:
                suggestion_messages.append(f"⚠️ You have outstanding debts of ₹{profile.debts}. Try reducing them.")
            else:
                suggestion_messages.append("✅ No debts. Keep up good financial health.")

            if getattr(profile, 'monthly_investment', 0) > 0:
                suggestion_messages.append("💡 Your current investments are on track.")
            else:
                suggestion_messages.append("💡 Consider starting small investments based on your risk tolerance.")

            risk = getattr(profile, 'risk_tolerance', 'Medium')
            if risk.lower() == "high":
                suggestion_messages.append("⚠️ High risk tolerance. Diversify your investments.")
            elif risk.lower() == "low":
                suggestion_messages.append("✅ Low risk tolerance. Prefer safer investments.")

            if getattr(profile, 'monthly_savings_goal', 0) > net_savings:
                suggestion_messages.append("⚠️ Your savings goal is higher than your current net savings. Please adjust your budget.")

            if getattr(profile, 'financial_goals', ''):
                suggestion_messages.append(f"💡 Your financial goal: {profile.financial_goals}")

            # Gmail transaction-based suggestions
            gmail_suggestions = []
            try:
                transactions = fetch_recent_transactions(request.user.email)
                if transactions:
                    gmail_suggestions = generate_suggestions(profile.__dict__, transactions)
            except Exception as e:
                print("Error fetching Gmail transactions:", e)
                gmail_suggestions.append("⚠️ Could not fetch Gmail transactions. Check Gmail API setup.")

            # Combine all suggestions and save to profile
            profile.suggestion = "\n".join(suggestion_messages + gmail_suggestions)

            # Train ML model
            train_model(FinancialProfile.objects.all())

            # Predict assistance requirement
            assistance_required = predict_assistance(profile)
            if assistance_required is None:
                assistance_required = net_savings <= 10000 or profile.credit_score < 700

            # Save the profile (create or update)
            profile.save()

            # Create a new AssistanceResult (history) every submission
            try:
                user_profile = UserProfile.objects.get(user=request.user)
                AssistanceResult.objects.create(
                    user=user_profile,
                    assistance_required=assistance_required,
                    suggestion=profile.suggestion,
                    submitted_at=timezone.now()  # If you have the field
                )
            except UserProfile.DoesNotExist:
                pass

            # Send notification email with suggestions
            try:
                email_subject = "Your Financial Assistance Request Received"
                email_message = f"""
Dear {request.user.get_full_name() or request.user.username},

Your financial assistance request has been submitted successfully.

Here are your personalized suggestions:

{profile.suggestion}

Thank you for using our system.
"""
                send_mail(
                    email_subject,
                    email_message,
                    settings.DEFAULT_FROM_EMAIL,
                    [request.user.email],
                    fail_silently=False,
                )
            except Exception as e:
                print("Email sending error:", e)

            # Render result page with suggestions and prediction
            return render(request, "assistance/result.html", {
                "profile": profile,
                "suggestions": suggestion_messages,
                "gmail_suggestions": gmail_suggestions,
                "ml_assistance_required": assistance_required,
            })

        else:
            # Form invalid: re-render with errors
            return render(request, "assistance/home.html", {"form": form})
    else:
        # GET request: render empty form
        form = FinancialProfileForm()
        return render(request, "assistance/home.html", {"form": form})
