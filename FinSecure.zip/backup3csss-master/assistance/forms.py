# assistance/forms.py

from django import forms
from .models import FinancialProfile

class FinancialProfileForm(forms.ModelForm):
    """
    Comprehensive form to capture detailed user financial profile.
    Collects income, expenses, credit score, occupation, risk tolerance, and additional financial info.
    """

    # Choices for risk tolerance
    RISK_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High')
    ]

    # Additional financial fields
    monthly_savings_goal = forms.FloatField(
        label="Monthly Savings Goal (₹)",
        required=True,
        help_text="Amount you aim to save each month.",
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Monthly Savings Goal in ₹',
            'min': 0
        })
    )
    risk_tolerance = forms.ChoiceField(
        choices=RISK_CHOICES,
        label="Risk Tolerance",
        required=True,
        help_text="Select your risk tolerance for investments.",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    monthly_investments = forms.FloatField(
        label="Monthly Investments (₹)",
        required=False,
        help_text="Amount already invested monthly in mutual funds, stocks, etc.",
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Monthly Investments in ₹',
            'min': 0
        })
    )
    debts = forms.FloatField(
        label="Total Debts (₹)",
        required=False,
        help_text="Outstanding debts such as loans, credit cards, etc.",
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Total Debts in ₹',
            'min': 0
        })
    )
    financial_goals = forms.CharField(
        label="Financial Goals",
        required=False,
        help_text="Describe your short-term or long-term financial goals.",
        widget=forms.Textarea(attrs={
            'rows': 3,
            'class': 'form-control',
            'placeholder': 'E.g., Buy a house, retirement planning'
        })
    )

    class Meta:
        model = FinancialProfile
        fields = [
            'name',
            'occupation',
            'income',
            'expenses',
            'credit_score',
            'monthly_savings_goal',
            'risk_tolerance',
            'monthly_investments',
            'debts',
            'financial_goals'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'occupation': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Occupation'}),
            'income': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Monthly Income in ₹', 'min': 0}),
            'expenses': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Monthly Expenses in ₹', 'min': 0}),
            'credit_score': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Credit Score (300-900)', 'min': 300, 'max': 900}),
        }
        help_texts = {
            'credit_score': 'Enter your credit score (e.g., 650-850)',
        }
