# assistance/ml_model.py

import joblib
import os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from .models import FinancialProfile

# Model file path
MODEL_FILE = "assistance_ml_model.pkl"

# Global LabelEncoders (will be trained/saved along with the model)
le_occupation = LabelEncoder()
le_risk = LabelEncoder()

def train_model(profiles=None):
    """
    Train ML model using historical FinancialProfile data.
    Saves the model along with LabelEncoders to disk.
    """
    if profiles is None:
        profiles = FinancialProfile.objects.all()
    
    if not profiles.exists():
        return None

    X, y = [], []
    occupations, risks = [], []

    # Prepare data
    for p in profiles:
        occupations.append(p.occupation if p.occupation else "Unknown")
        risks.append(getattr(p, 'risk_tolerance', 'Medium'))
        X.append([
            p.income,
            p.expenses,
            p.credit_score,
            getattr(p, 'debts', 0.0),
            getattr(p, 'monthly_investment', 0.0)
        ])
        net_savings = p.income - p.expenses
        y.append(1 if net_savings <= 10000 or p.credit_score < 700 else 0)  # 1 = assistance required

    # Encode categorical features
    le_occupation.fit(occupations)
    le_risk.fit(risks)
    occ_encoded = le_occupation.transform(occupations)
    risk_encoded = le_risk.transform(risks)

    # Merge numeric and encoded categorical features
    X = np.array(X)
    X = np.column_stack([X, occ_encoded, risk_encoded])
    y = np.array(y)

    # Train RandomForestClassifier
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X, y)

    # Save model and encoders
    joblib.dump({
        "model": clf,
        "le_occupation": le_occupation,
        "le_risk": le_risk
    }, MODEL_FILE)

    return clf

def predict_assistance(profile):
    """
    Predict if assistance is required for a given FinancialProfile instance.
    Returns True if assistance is needed, False otherwise.
    """
    if not os.path.exists(MODEL_FILE):
        return None  # Model not trained yet

    data = joblib.load(MODEL_FILE)
    clf = data["model"]
    le_occupation = data["le_occupation"]
    le_risk = data["le_risk"]

    # Encode categorical features
    occupation = profile.occupation if profile.occupation else "Unknown"
    risk = getattr(profile, 'risk_tolerance', 'Medium')

    # Handle unseen categories gracefully
    try:
        occ_encoded = le_occupation.transform([occupation])[0]
    except ValueError:
        occ_encoded = 0  # default index for unseen occupation

    try:
        risk_encoded = le_risk.transform([risk])[0]
    except ValueError:
        risk_encoded = 1  # default index for unseen risk

    # Prepare test features
    X_test = np.array([[
        profile.income,
        profile.expenses,
        profile.credit_score,
        getattr(profile, 'debts', 0.0),
        getattr(profile, 'monthly_investment', 0.0),
        occ_encoded,
        risk_encoded
    ]])

    # Predict
    prediction = clf.predict(X_test)[0]
    return bool(prediction)
