from django.db import models
from users.models import UserProfile
from django.contrib.auth.models import User

from django.contrib.auth.models import User
from django.db import models

# --- Model 1: Assistance Results linked to User ---
from django.utils import timezone


class AssistanceResult(models.Model):
    user = models.ForeignKey(
        'users.UserProfile',  # Use app label if imported lazily
        on_delete=models.CASCADE,
        related_name="assistance_results"
    )
    assistance_required = models.BooleanField()
    suggestion = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    submitted_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        status = "Required" if self.assistance_required else "Not Required"
        return f"Assistance for {self.user.user.username} ({status}) on {self.created_at.strftime('%Y-%m-%d %H:%M')}"

# --- Model 2: Financial Profile ---


class FinancialProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, unique=True)
    name = models.CharField(max_length=100)
    occupation = models.CharField(max_length=100, blank=True)
    income = models.FloatField()
    expenses = models.FloatField()
    credit_score = models.IntegerField()
    savings = models.FloatField(default=0.0)
    debts = models.FloatField(default=0.0)
    monthly_investment = models.FloatField(default=0.0)
    suggestion = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} | Income: {self.income}"


# --- Model 3: Purchase Alerts from Gmail ---
class PurchaseAlert(models.Model):
    sender = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    snippet = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Purchase Alert: {self.subject} ({self.sender})"
